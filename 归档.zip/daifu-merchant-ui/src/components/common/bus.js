// 利用bus来实现非父子组件（兄弟组件）间的通信

import Vue from 'vue';
export default new Vue();
